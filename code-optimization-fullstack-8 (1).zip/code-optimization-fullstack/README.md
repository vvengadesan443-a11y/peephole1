# Code Optimization Studio — DAG & Peephole

Full-stack compiler-design project. Frontend: HTML/CSS/JavaScript. Backend: Python + Flask.

## Features
- **Three-address code mode:** real DAG construction (common subexpressions, constant folding,
  copy propagation, dead code) + peephole optimization (algebraic simplification, strength reduction,
  redundant copies, dead stores). The DAG is drawn as a diagram.
- **Target code mode (with labels and jumps):** the five classic peephole techniques —
  redundant load/store elimination, unreachable code elimination, flow-of-control optimization,
  algebraic simplification & strength reduction, machine idioms.
- Step-by-step trace ("What changed?"), copy button, and an equivalence check that runs the original
  and optimized code on random inputs.

## Run locally
```bash
python -m venv .venv
# Windows:  .venv\Scripts\activate
# macOS/Linux:  source .venv/bin/activate
pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:5000

## Structure
```
app.py            Flask server (POST /api/optimize)
optimizer.py      three-address code: DAG + peephole
peephole_asm.py   target code: 5 peephole techniques
templates/index.html
static/app.js, static/style.css
```

## Example inputs
Three-address code:
```
t1 = a + b
t2 = a + b
t3 = t2 * 1
t4 = 3 * 4
result = t3 + t4
```
Target code:
```
    LD R0, a
    ST a, R0
    GOTO L2
    ADD R1, R1, #1
L2: HALT
```

## Limitations
Educational optimizer, not a full compiler: three-address mode handles one basic block; target mode handles
the simple instruction set listed in the UI. Variables named t1, t2… are temporaries; others are live at the end.

## GitHub
Upload all files preserving the folders. GitHub Pages cannot run Flask; use a Python host such as Render or PythonAnywhere.
