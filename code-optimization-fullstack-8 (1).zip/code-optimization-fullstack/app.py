from flask import Flask, render_template, request, jsonify

from optimizer import ParseError, optimize
from peephole_asm import AsmError, optimize_asm

app = Flask(__name__)


def _steps_tac(result):
    """Turn optimizer output into the 'what changed' trace shown in the UI."""
    steps = []
    dag = result.get("dag")
    if dag:
        for s in dag["steps"]:
            left, _, right = s.partition("  →  ")
            if "common subexpression" in right or "constant folding" in right:
                steps.append({"technique": "DAG", "detail": right, "before": left, "after": ""})
    pe = result.get("peephole")
    if pe:
        for e in pe["log"]:
            steps.append({
                "technique": "Peephole",
                "detail": e["rule"],
                "before": " ; ".join(e["before"]),
                "after": " ; ".join(e["after"]) or "(removed)",
            })
    return steps


def _view(result):
    kind = result.get("kind", "tac")
    if kind == "asm":
        steps = [{"technique": e["technique"], "detail": e["rule"],
                  "before": " ; ".join(e["before"]),
                  "after": " ; ".join(e["after"]) or "(removed)"}
                 for e in result["peephole"]["log"]]
    else:
        steps = _steps_tac(result)
    view = {
        "kind": kind,
        "original": "\n".join(result["original"]),
        "optimized": "\n".join(result["final"]),
        "steps": steps,
        "summary": {
            "input_lines": len(result["original"]),
            "output_lines": len(result["final"]),
            "optimizations": len(steps),
        },
        "verified": result["stats"]["verified"],
        "warnings": result.get("warnings", []),
        "techniques": result.get("techniques", []),
    }
    if result.get("dag"):
        view["dag"] = {"nodes": result["dag"]["nodes"], "construction": result["dag"]["steps"]}
    return view


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/optimize", methods=["POST"])
def api_optimize():
    payload = request.get_json(silent=True) or {}
    code = payload.get("code", "")
    kind = payload.get("kind", "tac")
    techniques = payload.get("techniques", ["dag", "peephole"])
    if not isinstance(code, str) or not code.strip():
        return jsonify({"error": "Please enter some code to optimize."}), 400
    if len(code) > 20000:
        return jsonify({"error": "Input is too large."}), 400
    try:
        if kind == "asm":
            return jsonify(_view(optimize_asm(code)))
        use_dag, use_pe = "dag" in techniques, "peephole" in techniques
        if not (use_dag or use_pe):
            return jsonify({"error": "Select at least one optimization technique."}), 400
        mode = "both" if use_dag and use_pe else "dag" if use_dag else "peephole"
        return jsonify(_view(optimize(code, mode)))
    except (ParseError, AsmError) as exc:
        return jsonify({"error": str(exc)}), 400
    except Exception as exc:  # keep the UI usable on unexpected input
        app.logger.exception("Optimization failed")
        return jsonify({"error": f"Could not optimize this input: {exc}"}), 400


if __name__ == "__main__":
    app.run(debug=True)
