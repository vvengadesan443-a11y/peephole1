"""
Code optimizer: DAG-based local optimization + peephole optimization
for straight-line three-address code (a single basic block).

Supported statements:
    x = y            (copy)
    x = -y           (unary minus)
    x = y op z       (op in + - * / % << >>)
Operands are identifiers or numbers. '#' or '//' start a comment.
Names like t1, t2 ... are treated as compiler temporaries (dead at block end);
every other variable is assumed live at the end of the block.
"""
import math
import random
import re

IDENT = r'[A-Za-z_][A-Za-z0-9_]*'
NUM = r'-?\d+(?:\.\d+)?'
ATOM = rf'(?:{IDENT}|{NUM})'
LINE_RE = re.compile(
    rf'^\s*({IDENT})\s*=\s*'
    rf'(?:({ATOM})\s*(\+|-|\*|/|%|<<|>>)\s*({ATOM})|(-)?\s*({ATOM}))\s*;?\s*$'
)
TEMP_RE = re.compile(r'^t\d+$')
NUM_RE = re.compile(rf'^{NUM}$')
COMMUTATIVE = {'+', '*'}


class ParseError(Exception):
    pass


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------
def is_num(s):
    return s is not None and bool(NUM_RE.match(s))


def num(s):
    return float(s) if '.' in s else int(s)


def show(v):
    return repr(round(v, 10)) if isinstance(v, float) else str(v)


def fmt(i):
    if i['op'] is None:
        return f"{i['dest']} = {i['a']}"
    if i['op'] == 'neg':
        return f"{i['dest']} = -{i['a']}"
    return f"{i['dest']} = {i['a']} {i['op']} {i['b']}"


def reads(i):
    return [x for x in (i['a'], i['b']) if x and not is_num(x)]


def parse(text):
    prog = []
    for no, raw in enumerate(text.splitlines(), 1):
        line = raw.split('#')[0].split('//')[0].strip()
        if not line:
            continue
        m = LINE_RE.match(line)
        if not m:
            raise ParseError(
                f"Line {no}: cannot parse '{raw.strip()}'. "
                "Use forms like  t1 = a + b ,  x = y ,  x = -y"
            )
        dest, a, op, b, neg, single = m.groups()
        if op:
            prog.append({'dest': dest, 'op': op, 'a': a, 'b': b})
        elif neg:
            prog.append({'dest': dest, 'op': 'neg', 'a': single, 'b': None})
        else:
            prog.append({'dest': dest, 'op': None, 'a': single, 'b': None})
    if not prog:
        raise ParseError("Please enter at least one instruction.")
    return prog


def fold(op, a, b):
    """Constant-fold a op b. Returns None when folding is unsafe."""
    try:
        if op == '+':
            return a + b
        if op == '-':
            return a - b
        if op == '*':
            return a * b
        if op == '/':
            if b == 0:
                return None
            if isinstance(a, int) and isinstance(b, int):
                return a // b if a % b == 0 else None
            return a / b
        if op == '%':
            if b == 0 or not (isinstance(a, int) and isinstance(b, int)):
                return None
            return a % b
        if op in ('<<', '>>'):
            if not (isinstance(a, int) and isinstance(b, int) and 0 <= b < 32):
                return None
            return a << b if op == '<<' else a >> b
    except Exception:
        return None
    return None


# --------------------------------------------------------------------------
# Technique 1: DAG construction (CSE, constant folding, copy propagation,
#              dead code elimination)
# --------------------------------------------------------------------------
def build_dag(prog):
    nodes, table, var_node, steps = [], {}, {}, []

    def new(kind, **kw):
        n = {'id': len(nodes), 'kind': kind, 'op': None, 'args': [],
             'name': None, 'value': None, 'labels': []}
        n.update(kw)
        nodes.append(n)
        return n['id']

    def const(v):
        key = ('const', show(v))
        if key not in table:
            table[key] = new('const', name=show(v), value=v)
        return table[key]

    def get(atom):
        if is_num(atom):
            return const(num(atom))
        if atom in var_node:
            return var_node[atom]
        key = ('var', atom)
        if key not in table:
            table[key] = new('var', name=atom)
        return table[key]

    for ins in prog:
        d, op, text = ins['dest'], ins['op'], fmt(ins)
        if op is None:
            n = get(ins['a'])
            steps.append(f"{text}  →  copy: label '{d}' joins node n{n}")
        else:
            x = get(ins['a'])
            y = get(ins['b']) if op != 'neg' else None
            folded = None
            if op == 'neg' and nodes[x]['kind'] == 'const':
                folded = -nodes[x]['value']
            elif op != 'neg' and nodes[x]['kind'] == 'const' and nodes[y]['kind'] == 'const':
                folded = fold(op, nodes[x]['value'], nodes[y]['value'])
            if folded is not None:
                n = const(folded)
                steps.append(f"{text}  →  constant folding: result is {show(folded)} (node n{n})")
            else:
                args = [x] if op == 'neg' else [x, y]
                keyargs = tuple(sorted(args)) if op in COMMUTATIVE else tuple(args)
                key = (op, keyargs)
                if key in table:
                    n = table[key]
                    steps.append(f"{text}  →  common subexpression: reuse node n{n}")
                else:
                    n = new('op', op=op, args=args)
                    table[key] = n
                    kids = ", ".join(f"n{a}" for a in args)
                    steps.append(f"{text}  →  new node n{n} ({op}) with children {kids}")
        for m in nodes:
            if d in m['labels']:
                m['labels'].remove(d)
        nodes[n]['labels'].append(d)
        var_node[d] = n

    # ---- decide what must be kept (live-out = non-temporaries) ----
    assigned = []
    for i in prog:
        if i['dest'] not in assigned:
            assigned.append(i['dest'])
    live = [v for v in assigned if not TEMP_RE.match(v)] or assigned

    reach, stack = set(), [var_node[v] for v in live]
    while stack:
        n = stack.pop()
        if n in reach:
            continue
        reach.add(n)
        stack.extend(nodes[n]['args'])

    live_of = {}
    for v in live:
        live_of.setdefault(var_node[v], []).append(v)

    used = {s for i in prog for s in (i['dest'], i['a'], i['b']) if s and not is_num(s)}
    counter = [0]

    def fresh():
        while True:
            counter[0] += 1
            nm = f"t{counter[0]}"
            if nm not in used:
                used.add(nm)
                return nm

    # ---- code generation -------------------------------------------------
    # Each live variable must end up holding its final node's value. A write to a
    # variable is held back while some not-yet-emitted instruction still needs that
    # variable's OLD value; if a node's preferred name is still needed it gets a
    # fresh temporary, and copy cycles (swaps) are broken with a temporary.
    leaf_id = {k[1]: v for k, v in table.items() if k[0] == 'var'}
    home = {n['id']: n['name'] for n in nodes
            if n['id'] in reach and n['kind'] in ('var', 'const')}
    interior = [n for n in nodes if n['id'] in reach and n['kind'] == 'op']
    emitted = set()
    code = []

    def cp(dest, src):
        return {'dest': dest, 'op': None, 'a': src, 'b': None}

    pending = []
    for v in live:
        nid = var_node[v]
        if nodes[nid]['kind'] != 'op' and home[nid] == v:
            continue                                  # x = x, nothing to do
        pending.append({'dest': v, 'src': nid, 'val': None})

    def has_readers(v, skip_node=None, skip_write=None):
        """Is the original value of variable v still needed by unemitted code?"""
        leaf = leaf_id.get(v)
        if leaf is None or leaf not in reach:
            return False
        for m in interior:
            if m['id'] not in emitted and m['id'] != skip_node and leaf in m['args']:
                return True
        return any(w is not skip_write and w['src'] == leaf and w['val'] is None
                   for w in pending)

    def drain(final):
        progress = True
        while progress:
            progress = False
            for w in list(pending):
                if nodes[w['src']]['kind'] == 'op':
                    if w['src'] not in emitted:
                        continue
                elif not final:
                    continue
                if has_readers(w['dest'], skip_write=w):
                    continue
                code.append(cp(w['dest'], w['val'] or home[w['src']]))
                pending.remove(w)
                progress = True
                break

    for n in interior:
        outs = live_of.get(n['id'], [])
        cands = outs + [l for l in n['labels'] if TEMP_RE.match(l) and l not in outs]
        h = None
        for c in cands:
            if not has_readers(c, skip_node=n['id']):
                h = c
                break
        if h is None:
            h = fresh()
        home[n['id']] = h
        a = home[n['args'][0]]
        b = home[n['args'][1]] if n['op'] != 'neg' else None
        code.append({'dest': h, 'op': n['op'], 'a': a, 'b': b})
        emitted.add(n['id'])
        for w in list(pending):                       # computed straight into its variable
            if w['src'] == n['id'] and w['dest'] == h:
                pending.remove(w)
        drain(False)
    drain(True)
    while pending:                                    # remaining copies form cycles
        w = next((x for x in pending
                  if nodes[x['src']]['kind'] == 'var' and x['val'] is None), None)
        if w is None:
            break
        t = fresh()
        code.append(cp(t, home[w['src']]))
        for x in pending:
            if x['src'] == w['src'] and x['val'] is None:
                x['val'] = t
        drain(True)

    dag_nodes = [{
        'id': n['id'], 'kind': n['kind'],
        'label': n['name'] if n['kind'] != 'op' else ('neg' if n['op'] == 'neg' else n['op']),
        'children': n['args'], 'labels': n['labels'], 'live': n['id'] in reach,
    } for n in nodes]
    return dag_nodes, steps, code


# --------------------------------------------------------------------------
# Technique 2: peephole optimization (sliding window over the instructions)
# --------------------------------------------------------------------------
def _is_live(name, prog, start, live_out=None):
    for j in range(start, len(prog)):
        if name in reads(prog[j]):
            return True
        if prog[j]['dest'] == name:
            return False
    if live_out is not None:
        return name in live_out
    return not TEMP_RE.match(name)


def _simplify(ins):
    d, op, a, b = ins['dest'], ins['op'], ins['a'], ins['b']

    def cp(s):
        return {'dest': d, 'op': None, 'a': s, 'b': None}

    def isv(s, v):
        return is_num(s) and num(s) == v

    if op is None:
        return None
    if op == 'neg':
        return ('Constant folding', cp(show(-num(a)))) if is_num(a) else None
    if is_num(a) and is_num(b):
        v = fold(op, num(a), num(b))
        return ('Constant folding', cp(show(v))) if v is not None else None
    if op == '+':
        if isv(b, 0):
            return ('Algebraic simplification (x + 0 → x)', cp(a))
        if isv(a, 0):
            return ('Algebraic simplification (0 + x → x)', cp(b))
    elif op == '-':
        if isv(b, 0):
            return ('Algebraic simplification (x - 0 → x)', cp(a))
        if a == b and not is_num(a):
            return ('Algebraic simplification (x - x → 0)', cp('0'))
    elif op == '*':
        if isv(b, 1):
            return ('Algebraic simplification (x * 1 → x)', cp(a))
        if isv(a, 1):
            return ('Algebraic simplification (1 * x → x)', cp(b))
        if isv(a, 0) or isv(b, 0):
            return ('Algebraic simplification (x * 0 → 0)', cp('0'))
        for x, c in ((a, b), (b, a)):
            if is_num(c) and not is_num(x) and isinstance(num(c), int):
                k = num(c)
                if k >= 2 and (k & (k - 1)) == 0:
                    sh = k.bit_length() - 1
                    if sh == 1:
                        return ('Strength reduction (x * 2 → x + x)',
                                {'dest': d, 'op': '+', 'a': x, 'b': x})
                    return (f'Strength reduction (x * {k} → x << {sh})',
                            {'dest': d, 'op': '<<', 'a': x, 'b': str(sh)})
    elif op == '/':
        if isv(b, 1):
            return ('Algebraic simplification (x / 1 → x)', cp(a))
    elif op in ('<<', '>>'):
        if isv(b, 0):
            return ('Algebraic simplification (shift by 0)', cp(a))
    return None


def peephole(prog, live_out=None):
    prog = [dict(i) for i in prog]
    log = []

    def note(rule, before, after):
        log.append({'rule': rule, 'before': before, 'after': after})

    for _ in range(200):
        changed = False
        for i in range(len(prog)):
            ins = prog[i]
            before = fmt(ins)

            # 1. null sequence:  x = x
            if ins['op'] is None and ins['a'] == ins['dest']:
                note('Null sequence removal', [before], [])
                del prog[i]
                changed = True
                break
            # 2. dead store / unused temporary
            if not _is_live(ins['dest'], prog, i + 1, live_out):
                note('Dead store elimination', [before], [])
                del prog[i]
                changed = True
                break
            # 3. constant folding / algebraic / strength reduction
            r = _simplify(ins)
            if r:
                rule, new = r
                note(rule, [before], [fmt(new)])
                prog[i] = new
                changed = True
                break
            # 4. window rules (two consecutive instructions)
            if i + 1 < len(prog):
                nxt = prog[i + 1]
                pair = [before, fmt(nxt)]
                if (TEMP_RE.match(ins['dest']) and nxt['op'] is None
                        and nxt['a'] == ins['dest']
                        and not _is_live(ins['dest'], prog, i + 2, live_out)):
                    merged = dict(ins, dest=nxt['dest'])
                    note('Redundant copy elimination', pair, [fmt(merged)])
                    prog[i:i + 2] = [merged]
                    changed = True
                    break
                if (ins['op'] is None and nxt['op'] is None
                        and nxt['dest'] == ins['a'] and nxt['a'] == ins['dest']):
                    note('Redundant load/store elimination', pair, [before])
                    del prog[i + 1]
                    changed = True
                    break
        if not changed:
            break
    return prog, log


# --------------------------------------------------------------------------
# Verification: run original and optimized code on random inputs
# --------------------------------------------------------------------------
def _run(prog, env):
    env = dict(env)

    def val(s):
        return num(s) if is_num(s) else env[s]

    for i in prog:
        op = i['op']
        if op is None:
            r = val(i['a'])
        elif op == 'neg':
            r = -val(i['a'])
        else:
            x, y = val(i['a']), val(i['b'])
            if op == '+':
                r = x + y
            elif op == '-':
                r = x - y
            elif op == '*':
                r = x * y
            elif op == '/':
                r = x / y
            elif op == '%':
                r = x % y
            else:
                if abs(y) > 64:
                    raise OverflowError
                r = x * 2 ** y if op == '<<' else x // 2 ** y
        env[i['dest']] = r
    return env


def verify(a, b, trials=25):
    rng = random.Random(7)
    names = sorted({s for p in (a, b) for i in p
                    for s in (i['dest'], i['a'], i['b']) if s and not is_num(s)})
    assigned = []
    for i in a:
        if i['dest'] not in assigned:
            assigned.append(i['dest'])
    targets = [v for v in assigned if not TEMP_RE.match(v)] or assigned
    compared = 0
    for _ in range(trials):
        env = {n: rng.randint(1, 9) for n in names}
        try:
            ea, eb = _run(a, env), _run(b, env)
        except (ArithmeticError, ValueError, TypeError):
            continue
        for v in targets:
            if not math.isclose(ea[v], eb.get(v, float('nan')), rel_tol=1e-9, abs_tol=1e-9):
                return False
        compared += 1
    return True if compared else None


# --------------------------------------------------------------------------
# Public entry point
# --------------------------------------------------------------------------
def optimize(text, mode='both'):
    prog = parse(text)
    result = {'original': [fmt(i) for i in prog], 'warnings': []}
    current = prog
    stats = {'original': len(prog)}

    if mode in ('dag', 'both'):
        nodes, steps, code = build_dag(prog)
        ok = verify(prog, code)
        if ok is False:
            result['warnings'].append("DAG output failed verification; stage skipped.")
        else:
            current = code
        result['dag'] = {'nodes': nodes, 'steps': steps, 'code': [fmt(i) for i in code]}
        stats['dag'] = len(code)

    if mode in ('peephole', 'both'):
        # same live-out rule as the DAG stage: non-temporaries, or everything if there are none
        live_out = {i['dest'] for i in prog if not TEMP_RE.match(i['dest'])} or {i['dest'] for i in prog}
        code, log = peephole(current, live_out)
        ok = verify(prog, code)
        if ok is False:
            result['warnings'].append("Peephole output failed verification; stage skipped.")
        else:
            current = code
        result['peephole'] = {'log': log, 'code': [fmt(i) for i in code]}
        stats['peephole'] = len(code)

    result['final'] = [fmt(i) for i in current]
    stats['final'] = len(current)
    stats['verified'] = verify(prog, current)
    result['stats'] = stats
    return result
