"""
Peephole optimizer for simple target (assembly-like) code with labels and jumps.

Implements the five classic peephole techniques:
  1. Redundant instruction elimination (load/store)
  2. Unreachable code elimination
  3. Flow-of-control optimization
  4. Algebraic simplification and reduction in strength
  5. Use of machine idioms

Syntax (one instruction per line, optional "Label:" prefix, comments after ';'):
    LD R0, a        ST a, R0        MOV R1, R2 / #5
    ADD|SUB|MUL|DIV d, x, y         SHL|SHR d, x, #k
    INC R | DEC R | CLR R           NOP
    GOTO L          IF x == y GOTO L   (== != < <= > >=)
    RET | HALT
Immediates are written #5. Everything else is a register or memory name.
"""
import random
import re

LABEL_RE = re.compile(r'^([A-Za-z_]\w*)\s*:\s*(.*)$')
OPERAND_RE = re.compile(r'^(#-?\d+|[A-Za-z_]\w*)$')
NEG = {'==': '!=', '!=': '==', '<': '>=', '>=': '<', '>': '<=', '<=': '>'}
TERMINATORS = {'GOTO', 'RET', 'HALT'}
ARITY = {'LD': 2, 'ST': 2, 'MOV': 2, 'ADD': 3, 'SUB': 3, 'MUL': 3, 'DIV': 3,
         'SHL': 3, 'SHR': 3, 'INC': 1, 'DEC': 1, 'CLR': 1, 'NOP': 0,
         'GOTO': 1, 'RET': 0, 'HALT': 0}
TECHNIQUES = [
    'Redundant instruction elimination',
    'Unreachable code elimination',
    'Flow-of-control optimization',
    'Algebraic simplification & strength reduction',
    'Machine idioms',
]
T1, T2, T3, T4, T5 = TECHNIQUES


class AsmError(Exception):
    pass


def is_imm(s):
    return bool(re.fullmatch(r'#-?\d+', s))


def imm(s):
    return int(s[1:])


def pow2(v):
    return v >= 2 and (v & (v - 1)) == 0


def cmp_(x, rel, y):
    return {'==': x == y, '!=': x != y, '<': x < y,
            '<=': x <= y, '>': x > y, '>=': x >= y}[rel]


# ------------------------------------------------------------------ parsing
def _parse_instr(line, no, labels):
    def bad(msg=None):
        raise AsmError(f"Line {no}: {msg or 'cannot parse'} '{line}'")

    m = re.match(r'^([A-Za-z]+)\s*(.*)$', line)
    if not m:
        bad()
    op, rest = m.group(1).upper(), m.group(2).strip()
    if op == 'IF':
        mm = re.match(r'^([#\-\w]+)\s*(==|!=|<=|>=|<|>)\s*([#\-\w]+)\s+GOTO\s+([A-Za-z_]\w*)$',
                      rest, re.I)
        if not mm:
            bad("expected  IF x == y GOTO L  in")
        x, rel, y, t = mm.groups()
        for o in (x, y):
            if not OPERAND_RE.match(o):
                bad(f"bad operand '{o}' in")
        return {'labels': labels, 'op': 'IF', 'args': [x, rel, y, t]}
    if op not in ARITY:
        bad(f"unknown instruction '{op}' in")
    args = [a.strip() for a in rest.split(',')] if rest else []
    if len(args) != ARITY[op]:
        bad(f"{op} needs {ARITY[op]} operand(s) in")
    for a in args:
        if not (OPERAND_RE.match(a) if op != 'GOTO' else re.match(r'^[A-Za-z_]\w*$', a)):
            bad(f"bad operand '{a}' in")
    dest_idx = {'LD': 0, 'ST': 0, 'MOV': 0, 'ADD': 0, 'SUB': 0, 'MUL': 0, 'DIV': 0,
                'SHL': 0, 'SHR': 0, 'INC': 0, 'DEC': 0, 'CLR': 0}
    if op in dest_idx and is_imm(args[dest_idx[op]]):
        bad("destination cannot be an immediate in")
    return {'labels': labels, 'op': op, 'args': args}


def parse_asm(text):
    prog, pending = [], []
    for no, raw in enumerate(text.splitlines(), 1):
        line = raw.split(';')[0].split('//')[0].strip()
        while line:
            m = LABEL_RE.match(line)
            if not m:
                break
            pending.append(m.group(1))
            line = m.group(2).strip()
        if not line:
            continue
        prog.append(_parse_instr(line, no, pending))
        pending = []
    if not prog:
        raise AsmError("Please enter at least one instruction.")
    prog.append({'labels': pending, 'op': 'END', 'args': []})
    defined = {l for i in prog for l in i['labels']}
    for i in prog:
        if i['op'] in ('GOTO', 'IF') and i['args'][-1] not in defined:
            raise AsmError(f"Jump to undefined label '{i['args'][-1]}'.")
    return prog


def fmt_ins(i):
    op, a = i['op'], i['args']
    if op == 'END':
        body = ''
    elif op == 'IF':
        body = f"IF {a[0]} {a[1]} {a[2]} GOTO {a[3]}"
    elif op == 'GOTO':
        body = f"GOTO {a[0]}"
    elif a:
        body = f"{op} {', '.join(a)}"
    else:
        body = op
    return (''.join(f"{l}: " for l in i['labels']) + body).strip()


def fmt_prog(prog):
    return [fmt_ins(i) for i in prog if not (i['op'] == 'END' and not i['labels'])]


# -------------------------------------------------------------- algebra
def _algebra(op, d, x, y):
    def m(rule, s):
        return (rule, 'MOV', [d, s])

    if is_imm(x) and is_imm(y):
        a, b = imm(x), imm(y)
        if op == 'ADD':
            v = a + b
        elif op == 'SUB':
            v = a - b
        elif op == 'MUL':
            v = a * b
        else:
            if b == 0:
                return None
            v = a // b
        return m('Constant folding', f'#{v}')
    if op == 'ADD':
        if y == '#0':
            return m('x + 0 → x', x)
        if x == '#0':
            return m('0 + x → x', y)
    elif op == 'SUB':
        if y == '#0':
            return m('x − 0 → x', x)
        if x == y:
            return m('x − x → 0', '#0')
    elif op == 'MUL':
        if y == '#1':
            return m('x * 1 → x', x)
        if x == '#1':
            return m('1 * x → x', y)
        if x == '#0' or y == '#0':
            return m('x * 0 → 0', '#0')
        for p, c in ((x, y), (y, x)):
            if is_imm(c) and not is_imm(p) and pow2(imm(c)):
                k = imm(c).bit_length() - 1
                if k == 1:
                    return ('Strength reduction: x * 2 → x + x', 'ADD', [d, p, p])
                return (f'Strength reduction: x * {imm(c)} → x << {k}', 'SHL', [d, p, f'#{k}'])
    elif op == 'DIV':
        if y == '#1':
            return m('x / 1 → x', x)
        if is_imm(y) and not is_imm(x) and pow2(imm(y)):
            k = imm(y).bit_length() - 1
            return (f'Strength reduction: x / {imm(y)} → x >> {k}', 'SHR', [d, x, f'#{k}'])
    return None


# ------------------------------------------------------------- optimizer
def _step(prog, note):
    n = len(prog)
    idx = {l: k for k, ins in enumerate(prog) for l in ins['labels']}
    refs = {ins['args'][-1] for ins in prog if ins['op'] in ('GOTO', 'IF')}

    def snap(*ks):
        return [fmt_ins(prog[k]) for k in ks]

    def delete(i):  # an instruction's labels move to the next instruction
        prog[i + 1]['labels'] = prog[i]['labels'] + prog[i + 1]['labels']
        del prog[i]

    for i, ins in enumerate(prog):
        op, a = ins['op'], ins['args']
        nxt = prog[i + 1] if i + 1 < n else None

        # unused labels block other rules (e.g. a labelled store), so drop them first
        for l in ins['labels']:
            if l not in refs:
                before = snap(i)
                ins['labels'].remove(l)
                note(T3, f"Unused label {l} removed", before, snap(i))
                return True
        if op == 'END':
            continue

        # ---- 2. unreachable code: unlabelled instruction right after a jump/return
        if op in TERMINATORS and nxt is not None and nxt['op'] != 'END' and not nxt['labels']:
            note(T2, 'Unlabelled instruction after unconditional jump is unreachable',
                 snap(i + 1), [])
            delete(i + 1)
            return True

        # ---- 3. flow of control
        if op in ('GOTO', 'IF'):
            t = a[-1]
            if op == 'IF' and is_imm(a[0]) and is_imm(a[2]):
                before = snap(i)
                if cmp_(imm(a[0]), a[1], imm(a[2])):
                    ins['op'], ins['args'] = 'GOTO', [t]
                    note(T3, 'Condition is always true → unconditional jump', before, snap(i))
                else:
                    note(T3, 'Condition is always false → jump removed', before, [])
                    delete(i)
                return True
            if nxt is not None and t in nxt['labels']:
                note(T3, 'Jump to the next instruction removed', snap(i), [])
                delete(i)
                return True
            seen, cur = {t}, t
            while prog[idx[cur]]['op'] == 'GOTO':
                nx = prog[idx[cur]]['args'][0]
                if nx in seen:
                    cur = None
                    break
                seen.add(nx)
                cur = nx
            if cur and cur != t:
                before = snap(i)
                a[-1] = cur
                note(T3, f'Jump to jump: {t} → {cur}', before, snap(i))
                return True
            if (op == 'IF' and nxt is not None and nxt['op'] == 'GOTO' and not nxt['labels']
                    and i + 2 < n and t in prog[i + 2]['labels']):
                before = snap(i, i + 1)
                a[1], a[3] = NEG[a[1]], nxt['args'][0]
                del prog[i + 1]
                note(T3, 'Conditional jump over an unconditional jump inverted', before, snap(i))
                return True

        # ---- 1. redundant instruction elimination
        if nxt is not None and not nxt['labels']:
            if op == 'LD' and nxt['op'] == 'ST' and nxt['args'] == [a[1], a[0]]:
                note(T1, 'Redundant store: value was just loaded from the same location',
                     snap(i, i + 1), snap(i))
                delete(i + 1)
                return True
            if op == 'ST' and nxt['op'] == 'LD' and nxt['args'] == [a[1], a[0]]:
                note(T1, 'Redundant load: value was just stored from the same register',
                     snap(i, i + 1), snap(i))
                delete(i + 1)
                return True
        if op in ('MOV',) and a[0] == a[1]:
            note(T1, 'Null move removed (x = x)', snap(i), [])
            delete(i)
            return True
        if op == 'NOP':
            note(T1, 'NOP removed', snap(i), [])
            delete(i)
            return True

        # ---- 4. algebraic simplification / strength reduction
        if op in ('SHL', 'SHR') and a[2] == '#0':
            before = snap(i)
            ins['op'], ins['args'] = 'MOV', [a[0], a[1]]
            note(T4, 'Shift by 0 → copy', before, snap(i))
            return True
        if op in ('ADD', 'SUB', 'MUL', 'DIV'):
            r = _algebra(op, *a)
            if r:
                rule, new_op, new_args = r
                before = snap(i)
                ins['op'], ins['args'] = new_op, new_args
                note(T4, rule, before, snap(i))
                return True

        # ---- 5. machine idioms
        before = snap(i)
        if op == 'ADD' and (a[0] == a[1] and a[2] == '#1' or a[0] == a[2] and a[1] == '#1'):
            ins['op'], ins['args'] = 'INC', [a[0]]
            note(T5, 'ADD R, R, #1 → INC R', before, snap(i))
            return True
        if op == 'SUB' and a[0] == a[1] and a[2] == '#1':
            ins['op'], ins['args'] = 'DEC', [a[0]]
            note(T5, 'SUB R, R, #1 → DEC R', before, snap(i))
            return True
        if op == 'MOV' and a[1] == '#0':
            ins['op'], ins['args'] = 'CLR', [a[0]]
            note(T5, 'MOV R, #0 → CLR R', before, snap(i))
            return True
    return False


def peephole_asm(prog):
    prog = [{'labels': list(i['labels']), 'op': i['op'], 'args': list(i['args'])} for i in prog]
    log = []

    def note(tech, rule, before, after):
        log.append({'technique': tech, 'rule': rule, 'before': before, 'after': after})

    for _ in range(1000):
        if not _step(prog, note):
            break
    return prog, log


# ------------------------------------------------------------ verification
def _run(prog, env, limit=400):
    env = dict(env)
    idx = {l: k for k, ins in enumerate(prog) for l in ins['labels']}

    def val(s):
        return imm(s) if is_imm(s) else env[s]

    pc = steps = 0
    while pc < len(prog):
        ins = prog[pc]
        op, a = ins['op'], ins['args']
        steps += 1
        if steps > limit:
            raise TimeoutError
        pc += 1
        if op in ('LD', 'ST', 'MOV'):
            env[a[0]] = val(a[1])
        elif op in ('ADD', 'SUB', 'MUL', 'DIV', 'SHL', 'SHR'):
            x, y = val(a[1]), val(a[2])
            if op == 'ADD':
                r = x + y
            elif op == 'SUB':
                r = x - y
            elif op == 'MUL':
                r = x * y
            elif op == 'DIV':
                r = x // y
            else:
                if not 0 <= y < 64:
                    raise ValueError
                r = x << y if op == 'SHL' else x >> y
            if abs(r) > 10 ** 30:          # loops can square values forever; skip such trials
                raise OverflowError
            env[a[0]] = r
        elif op == 'INC':
            env[a[0]] += 1
        elif op == 'DEC':
            env[a[0]] -= 1
        elif op == 'CLR':
            env[a[0]] = 0
        elif op == 'GOTO':
            pc = idx[a[0]]
        elif op == 'IF':
            if cmp_(val(a[0]), a[1], val(a[2])):
                pc = idx[a[3]]
        elif op in ('RET', 'HALT'):
            break
    return env


def verify_asm(a, b, trials=25):
    names = set()
    for p in (a, b):
        for i in p:
            ops = i['args'][:-1] if i['op'] == 'GOTO' else (
                [i['args'][0], i['args'][2]] if i['op'] == 'IF' else i['args'])
            names |= {s for s in ops if not is_imm(s)}
    rng = random.Random(11)
    ok = 0
    for _ in range(trials):
        env = {n: rng.randint(1, 9) for n in names}
        try:
            ea = _run(a, env)
        except (ArithmeticError, ValueError, TimeoutError):
            continue
        try:
            eb = _run(b, env)
        except (ArithmeticError, ValueError, TimeoutError):
            return False
        if any(eb.get(k) != v for k, v in ea.items()):
            return False
        ok += 1
    return True if ok else None


def optimize_asm(text):
    prog = parse_asm(text)
    opt, log = peephole_asm(prog)
    ok = verify_asm(prog, opt)
    warnings = []
    if ok is False:
        warnings.append("Optimized code failed the equivalence check; showing the original.")
        opt, log = prog, []
    final = fmt_prog(opt)
    counts = [{'name': t, 'count': sum(1 for e in log if e['technique'] == t)} for t in TECHNIQUES]
    orig = fmt_prog(prog)
    return {
        'kind': 'asm',
        'original': orig,
        'final': final,
        'warnings': warnings,
        'techniques': counts,
        'peephole': {'log': log, 'code': final},
        'stats': {'original': len(orig), 'final': len(final), 'verified': ok if not warnings else False},
    }
