const $ = (id) => document.getElementById(id);
const sourceCode = $("sourceCode");
const optimizeBtn = $("optimizeBtn");
const originalOutput = $("originalOutput");
const optimizedOutput = $("optimizedOutput");
const stepsList = $("stepsList");
const message = $("message");
const kindSel = $("kind");
const exampleSel = $("example");

const EXAMPLES = {
  tac: {
    "Common subexpression": "t1 = a + b\nt2 = a + b\nt3 = t2 * 1\nt4 = 3 * 4\nresult = t3 + t4",
    "Textbook DAG": "t1 = 4 * i\nt2 = a + t1\nt3 = 4 * i\nt4 = b + t3\nt5 = t2 * t4\nprod = t5 + prod",
    "Peephole rules": "t1 = x * 1\nt2 = t1 + 0\ny = t2 * 8\nz = y * 2\nw = z - z",
    "Everything together": "t1 = 2 + 3\nt2 = a * t1\nt3 = a * 5\nt4 = t2 + t3\nt5 = t4 * 1\nr = t5\ns = r + 0\nunused = b * b",
  },
  asm: {
    "All five techniques": "    LD R0, a\n    ST a, R0\n    IF R0 == #1 GOTO L1\n    GOTO L2\nL1: MUL R1, R1, #8\n    ADD R2, R2, #1\n    GOTO L3\n    SUB R2, R2, #1\nL2: ADD R3, R3, #0\n    MOV R4, #0\nL3: GOTO L4\nL4: HALT",
    "Redundant load/store": "    LD R0, a\n    ST a, R0\n    ST b, R1\n    LD R1, b\n    ADD R1, R1, #1",
    "Store with a label (kept)": "    LD R0, a\nL1: ST a, R0\n    GOTO L1",
    "Unreachable code": "    GOTO L2\n    ADD R1, R1, #1\n    MUL R2, R2, #4\nL2: LD R0, b\n    HALT",
    "Flow of control": "    IF R0 < R1 GOTO L1\n    GOTO L2\nL1: GOTO L3\nL2: ADD R5, R5, #1\nL3: HALT",
    "Strength reduction & idioms": "    MUL R1, R1, #2\n    MUL R2, R3, #16\n    DIV R4, R4, #4\n    SUB R5, R5, #1\n    MOV R6, #0\n    ADD R7, R7, #0",
  },
};
const HINTS = {
  tac: "Supports x = y, x = -y and x = y op z with + − × ÷ % << >>. Names like t1 are temporaries; other variables are live at the end. One basic block, no jumps.",
  asm: "LD/ST/MOV · ADD/SUB/MUL/DIV d, x, y · SHL/SHR · INC/DEC/CLR · GOTO L · IF x == y GOTO L (== != < <= > >=) · RET/HALT. Labels as “L1:”, immediates as #5, comments after ;",
};

function setKind() {
  const kind = kindSel.value;
  exampleSel.replaceChildren();
  Object.keys(EXAMPLES[kind]).forEach((k) => exampleSel.add(new Option(k, k)));
  sourceCode.value = EXAMPLES[kind][exampleSel.value];
  $("techniqueRow").hidden = kind === "asm";
  $("hint").textContent = HINTS[kind];
  message.textContent = "";
}
kindSel.addEventListener("change", setKind);
exampleSel.addEventListener("change", () => { sourceCode.value = EXAMPLES[kindSel.value][exampleSel.value]; });
$("loadExample").addEventListener("click", () => {
  sourceCode.value = EXAMPLES[kindSel.value][exampleSel.value];
  message.textContent = "";
});
setKind();

optimizeBtn.addEventListener("click", runOptimization);
$("copyBtn").addEventListener("click", async () => {
  const text = optimizedOutput.textContent;
  try {
    await navigator.clipboard.writeText(text);
    $("copyBtn").textContent = "Copied ✓";
    setTimeout(() => ($("copyBtn").textContent = "Copy output"), 1400);
  } catch {
    message.textContent = "Clipboard permission is unavailable. Select and copy the output manually.";
  }
});

async function runOptimization() {
  message.textContent = "";
  const kind = kindSel.value;
  const techniques = [];
  if ($("dag").checked) techniques.push("dag");
  if ($("peephole").checked) techniques.push("peephole");
  if (kind === "tac" && !techniques.length) {
    message.textContent = "Select at least one optimization technique.";
    return;
  }
  optimizeBtn.disabled = true;
  optimizeBtn.innerHTML = "<span>…</span> Optimizing <span class='button-arrow'>↻</span>";
  try {
    const response = await fetch("/api/optimize", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ code: sourceCode.value, kind, techniques }),
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Optimization request failed.");
    render(data);
  } catch (error) {
    message.textContent = error.message + " Make sure the Flask backend is running.";
  } finally {
    optimizeBtn.disabled = false;
    optimizeBtn.innerHTML = "<span>✦</span> Optimize code <span class='button-arrow'>→</span>";
  }
}

function render(data) {
  originalOutput.textContent = data.original || "(empty)";
  optimizedOutput.textContent = data.optimized || "(no output)";
  $("inputLines").textContent = data.summary.input_lines;
  $("outputLines").textContent = data.summary.output_lines;
  $("stepCount").textContent = data.summary.optimizations;
  $("verified").textContent = data.verified === true ? "✓ Passed" : data.verified === false ? "✗ Failed" : "—";
  $("resultTag").textContent = "OPTIMIZATION COMPLETE";
  renderTechCounts(data.techniques || []);
  renderSteps(data.steps || []);
  if (data.dag) {
    $("dagBox").hidden = false;
    drawDag($("dagSvg"), data.dag.nodes);
    renderDagSteps(data.dag.construction);
  } else {
    $("dagBox").hidden = true;
  }
  if (data.warnings && data.warnings.length) message.textContent = data.warnings.join(" ");
}

function renderTechCounts(list) {
  const box = $("techCounts");
  box.replaceChildren();
  list.forEach((t) => {
    const chip = document.createElement("span");
    chip.className = "tech-chip" + (t.count ? "" : " zero");
    chip.textContent = t.name + " ";
    const b = document.createElement("b");
    b.textContent = t.count;
    chip.append(b);
    box.append(chip);
  });
}

function renderSteps(steps) {
  stepsList.replaceChildren();
  if (!steps.length) {
    const p = document.createElement("p");
    p.className = "empty-state";
    p.textContent = "No applicable optimization found for this input.";
    stepsList.appendChild(p);
    return;
  }
  steps.forEach((step, index) => {
    const card = document.createElement("article");
    card.className = "step";
    const top = document.createElement("div");
    top.className = "step-top";
    const pill = document.createElement("span");
    pill.className = "pill";
    pill.textContent = step.technique;
    const number = document.createElement("span");
    number.style.cssText = "font:10px var(--mono);color:#7f8da6";
    number.textContent = `STEP ${String(index + 1).padStart(2, "0")}`;
    top.append(pill, number);
    const detail = document.createElement("p");
    detail.textContent = step.detail;
    card.append(top, detail);
    const before = document.createElement("code");
    before.textContent = "Before: " + step.before;
    card.append(before);
    if (step.after) {
      const after = document.createElement("code");
      after.textContent = "After:  " + step.after;
      card.append(after);
    }
    stepsList.appendChild(card);
  });
}

function renderDagSteps(lines) {
  const box = $("dagSteps");
  box.replaceChildren();
  lines.forEach((l) => {
    const c = document.createElement("code");
    c.textContent = l;
    box.append(c);
  });
}

// ---- DAG drawing -------------------------------------------------------
const SVGNS = "http://www.w3.org/2000/svg";
function drawDag(svg, nodes) {
  svg.replaceChildren();
  const level = {};
  nodes.forEach((n) => {
    level[n.id] = n.children.length ? 1 + Math.max(...n.children.map((c) => level[c])) : 0;
  });
  const maxLevel = Math.max(...Object.values(level));
  const byLevel = {};
  nodes.forEach((n) => (byLevel[level[n.id]] ||= []).push(n));
  const gapX = 110, gapY = 95, pad = 50;
  const widest = Math.max(...Object.values(byLevel).map((a) => a.length));
  const W = Math.max(widest * gapX + pad, 320);
  const H = (maxLevel + 1) * gapY + pad;
  svg.setAttribute("viewBox", `0 0 ${W} ${H}`);
  svg.setAttribute("width", W);
  svg.setAttribute("height", H);

  const pos = {};
  Object.entries(byLevel).forEach(([lv, arr]) => {
    arr.forEach((n, i) => {
      pos[n.id] = { x: (W - arr.length * gapX) / 2 + gapX * (i + 0.5), y: H - pad / 2 - 15 - lv * gapY };
    });
  });

  const mk = (tag, attrs, text) => {
    const e = document.createElementNS(SVGNS, tag);
    Object.entries(attrs).forEach(([k, v]) => e.setAttribute(k, v));
    if (text !== undefined) e.textContent = text;
    svg.append(e);
  };

  nodes.forEach((n) => n.children.forEach((c) => {
    mk("line", {
      x1: pos[n.id].x, y1: pos[n.id].y, x2: pos[c].x, y2: pos[c].y,
      stroke: "#3b4a68", "stroke-width": 1.5, opacity: n.live ? 1 : 0.4,
      "stroke-dasharray": n.live ? "" : "4 3",
    });
  }));
  nodes.forEach((n) => {
    const { x, y } = pos[n.id];
    const isOp = n.kind === "op";
    mk("circle", {
      cx: x, cy: y, r: 20, fill: isOp ? "#82f0c8" : "#1b2740",
      stroke: isOp ? "#82f0c8" : "#a99bff", "stroke-width": 1.5,
      "stroke-dasharray": n.live ? "" : "4 3", opacity: n.live ? 1 : 0.5,
    });
    mk("text", {
      x, y: y + 4, "text-anchor": "middle", "font-size": 12, "font-family": "monospace",
      fill: isOp ? "#071b18" : "#edf3ff", "font-weight": isOp ? 700 : 400,
    }, n.label);
    if (n.labels.length) {
      mk("text", {
        x, y: y + 36, "text-anchor": "middle", "font-size": 11, "font-family": "monospace",
        fill: "#cdd9f1", opacity: n.live ? 1 : 0.5,
      }, n.labels.join(", "));
    }
    mk("text", { x: x + 22, y: y - 14, "font-size": 9, "font-family": "monospace", fill: "#91a0bb" }, "n" + n.id);
  });
}
